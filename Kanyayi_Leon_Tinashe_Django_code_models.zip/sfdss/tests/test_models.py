import unittest
from mongoengine import connect, disconnect
from sfdss.models import *

class ModelsTest(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        connect('mongoenginetest', host='mongomock://localhost', alias='testdb')
        """Comment out the below lines in setUpClass for first run as they are unnecessary and cause errors the first time"""
        # Campus.objects().first().delete()
        # Semesters.objects().first().delete()
        # Courses.objects().first().delete()
        # Departments.objects().first().delete()
        # Building.objects().first().delete()
        
    @classmethod
    def tearDownClass(cls):
        disconnect()
    
    def test_thing(self):
        campus = Campus(campus = "Jinshagang" )
        campus.save()
        test_campus = Campus.objects().first()
        
        semester = Semesters(semester_number = 1,semester_name = "Summer" )
        semester.save()
        test_semester = Semesters.objects().first()
        
        course_name = Courses(course_name = "example",course_id=1 )
        course_name.save()
        test_course = Courses.objects().first()
        
        department_name = Departments(department_name = "CIE" )
        department_name.save()
        test_dept = Departments.objects().first()
        
        """First Sanity Check on database for documents with no references"""
        assert test_campus.campus == "Jinshagang", "campus is wrong"
        
        assert test_semester.semester_name == "Summer" , "semester name is wrong"
        assert test_semester.semester_number == 1 , "semester number is wrong"
        
        assert test_course.course_name == "example","Course name is wrong"
        assert test_course.course_id == 1,"Course number is wrong"
        
        assert test_dept.department_name == "CIE", "department name is wrong"
        
        """ Second Sanity Check on database for documents with references"""
        building = Building(campus = Campus.objects().first(),building = "A",room_number = 101 )
        building.save()
        test_building = Building.objects().first()
        
        assert test_building.campus ==  test_campus,"Campus is wrong"
        assert test_building.building ==  "A","Building name is wrong"
        assert test_building.room_number == 101 ,"Building number is wrong"
        